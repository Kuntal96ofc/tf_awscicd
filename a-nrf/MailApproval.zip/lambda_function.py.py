import json
import boto3
from botocore.exceptions import ClientError


client=boto3.client('ses')

def lambda_handler(event, context):
    events=event["Records"][0]["Sns"]["Message"]
    events=json.loads(events)
    
    sub=events["detailType"]
    time=events["time"].rpartition("T")[0]+" "+events["time"].rpartition("T")[2].rpartition("Z")[0]+"UTC"
    status=events["detail"]["state"]
    
    sender="<SenderEmail>"
    recvr="<ReceiverEmail>"
    
    htnlmsg="""
    <html>
        <head>
        <style>
            table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            }
            #t01 {
            width: 100%;    
            background-color: Tomato;
            }
        </style>
        </head>
        <body>
            <p><h3>Hi,<br><br>Please find below the STATUS of your Pipeline's Execution</h3></p>
            
            <table id="t01" style="width:100%">
                <tr>
                    <th><b>PIPELINE STATE</b></th>
                    <th><b>EXECUTION TIME(UTC)</b></th>
                </tr>
                
                <tr >
                    <th>$(status)</th>
                    <th>$(time)</th>
                </tr>
                
                
            </table>
            <h3>For more details please check the logs under <a href="https://ap-southeast-1.console.aws.amazon.com/cloudwatch/home?region=ap-southeast-1#logsV2:log-groups/log-group/$252Faws$252Flambda$252FPipelineMailnotification" target="_blank">/aws/lambda/PipelineMailnotification</a></h3>
            <br>
            <h3>Regards,<br>Team</h3>
        </body>
    </html>
    """
    htnlmsg=htnlmsg.replace("$(status)",status)
    htnlmsg=htnlmsg.replace("$(time)",time)
    
    CHARSET = "UTF-8"
    try:
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    recvr,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                    'Charset': CHARSET,
                    'Data': htnlmsg,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': "hello",
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': sub,
                },
            },
            Source=sender,
        
        )

    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])