import json
from botocore.vendored import requests
import boto3
import securityhub
from datetime import datetime, timezone

pipeline = boto3.client('codepipeline')
s3 = boto3.client('s3')


def lambda_handler(event, context):

    try:

        print("Inside Main function....................")
        #project_name = event['CodePipeline.job']['data']['inputArtifacts'][0]['location']['s3Location']['objectKey']

        print(event)
        response= pipeline.get_job_details(jobId=event['CodePipeline.job']['id'])

        print(response)

        project_name = response['jobDetails']['data']['pipelineContext']['pipelineName']

        project_name=project_name.lstrip('pipeline-')

        project_name=project_name.rstrip('terraform')
        project_name=project_name.rstrip('-')

        print(project_name)

        sonarapi=f"https://sonarcloud.io/api/issues/search?componentKeys={project_name}&types=BUG,VULNERABILITY,CODE_SMELL"
        rawres = requests.get(sonarapi)
        res = rawres.json()
        issues = res['issues']


        print(sonarapi)
        print(issues)

        FINDING_TITLE = "SonarCloud StaticCode Analysis"
        count=1
        account_id= '<AWSAccount>'
        region= '<AWSRegion>'
        org=issues[0]['organization']
        prj=issues[0]['project']
        generator_id = f"{org}-{prj}"
        BEST_PRACTICES = "https://docs.aws.amazon.com/"


        #sending raw json to s3

        currentdate=datetime.now()
        s3bucket = "cicd-aws"
        key = f"reports/securituhub/{generator_id}-{currentdate}.json"
        s3.put_object(Bucket=s3bucket, Body=json.dumps(res), Key=key)
        report_url = f"https://s3.console.aws.amazon.com/s3/object/{s3bucket}/{key}?region={region}"



        for i in range(len(issues)):

            created_at = issues[i]['creationDate']
            key = issues[i]['key']
            finding_id = f"{region}/{account_id}/{key}"
            severity = issues[i]['severity']
            normalized_severity =  assign_normalized_severity(severity)
            finding_type = issues[i]['type']
            finding_description = issues[i]['message']

            #print(finding_id)
            securityhub.import_finding_to_sh(count, account_id, region, created_at, finding_id, generator_id, normalized_severity, finding_type, FINDING_TITLE, finding_description, BEST_PRACTICES,report_url)
            count+=1

    except:
        print("Something went wrong")

    finally:
        pipeline.put_job_success_result(jobId=event['CodePipeline.job']['id'])



def assign_normalized_severity(severity):
    if severity in ['MAJOR', 'MEDIUM', 'Med', 'Medium', 'medium']:
        normalized_severity = 70
        vul_level = "NOTLOW"
    elif severity in ['CRITICAL', 'BLOCKER', 'MAJOR', 'HIGH', 'Hig', 'High', 'high']:
        normalized_severity = 90
        vul_level = "NOTLOW"
    elif severity in ['LOW', 'Low', 'Inf', 'low', 'INFORMATIONAL']:
        normalized_severity = 20
        vul_level = "LOW"
    else:
        normalized_severity= 20
    return normalized_severity
