import boto3

securityhub = boto3.client('securityhub')



def import_finding_to_sh(count, account_id, region, created_at, finding_id, generator_id, normalized_severity, finding_type, FINDING_TITLE, finding_description, BEST_PRACTICES,report_url):


    print("called securityhub.py..................")
    new_findings = []

    new_findings.append({
        "SchemaVersion": "2018-10-08",
        "Id": finding_id,
        "ProductArn": "arn:aws:securityhub:{0}:{1}:product/{1}/default".format(region, account_id),
        "GeneratorId": generator_id,
        "AwsAccountId": account_id,
        "Types": [
            "Software and Configuration Checks/AWS Security Best Practices/{0}".format(
                finding_type)
        ],
        "CreatedAt": created_at,
        "UpdatedAt": created_at,
        "Severity": {
            "Normalized": normalized_severity,
        },
        "Title":  f"{count}-{FINDING_TITLE}",
        "Description": f"{finding_description}",
        'Remediation': {
            'Recommendation': {
                'Text': 'For directions on how to fix this issue, see the AWS Cloud Formation documentation and AWS Best practices',
                'Url': BEST_PRACTICES
            }
        },
        'SourceUrl': report_url,
        'Resources': [
            {
                'Id': "CodeBuild",
                'Type': "CodeBuild",
                'Partition': "aws",
                'Region': region
            }
        ],
    })
    response = securityhub.batch_import_findings(Findings=new_findings)

    print(response)
