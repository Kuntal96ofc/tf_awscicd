import json
import boto3
from botocore.exceptions import ClientError


client=boto3.client('ses')

def lambda_handler(event, context):
    events=event["Records"][0]["Sns"]["Message"]
    events=json.loads(events)
    
    pipelinename=events["detail"]["pipeline"]
    sub="Admin's Approval Needed"
    
    sender="<SenderEmail>"
    recvr="<ReceiverEmail>"
   
   
    htnlmsg="""
    <html>
        <head>
        <style>
            table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            }
            #t01 {
            width: 100%;    
            background-color: Tomato;
            }
        </style>
        </head>
        <body>
            <p><h3>Hi Admin,<br><br>Your Pipeline "$(pipelinename)" is awaiting your approval.<br>Kindly do the needful!</h3></p>
           
            <h3>For more details please check the logs under <a href="https://<AWSRegion>.console.aws.amazon.com/cloudwatch/home?region=<AWSRegion>#logsV2:log-groups/log-group/$252Faws$252Flambda$252FPipelineApprovalNotification" target="_blank">/aws/lambda/PipelineApprovalNotification</a></h3>
            <br>
            <h3>Regards,<br>Team</h3>
        </body>
    </html>
    """
    
    htnlmsg=htnlmsg.replace("$(pipelinename)",pipelinename)
    
    CHARSET = "UTF-8"
    try:
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    recvr,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                    'Charset': CHARSET,
                    'Data': htnlmsg,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': "hello",
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': sub,
                },
            },
            Source=sender,
        
        )

    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])
